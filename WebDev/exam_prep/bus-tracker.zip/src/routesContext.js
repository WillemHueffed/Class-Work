import { createContext } from "react"

const routesContext = createContext()
export default routesContext